<div class="sunrise-plugin-pane hide-if-js">
	<table class="form-table">