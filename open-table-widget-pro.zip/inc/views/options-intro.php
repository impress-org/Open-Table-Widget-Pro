<div class="options-intro">
    <h2><?php _e('Open Table Widget Plugin Options', $open_table_widget->textdomain); ?></h2>
    <p><?php _e('The following options set plugin defaults and options on a global level.', $open_table_widget->textdomain); ?> </p>
</div>